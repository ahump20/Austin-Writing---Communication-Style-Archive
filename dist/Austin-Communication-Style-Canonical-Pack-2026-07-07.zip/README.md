# Austin Humphrey Voice Router

> Evidence-backed communication router, voice skill, and reusable AI context system for Austin Humphrey.

[![License: All Rights Reserved](https://img.shields.io/badge/License-All%20Rights%20Reserved-red.svg)](#license)

## What This Is

This repo is the canonical communication router for Austin Humphrey's writing, public voice, private-register signals, and AI collaboration style. The archive matters because it proves the system. The system comes first.

The operating premise is simple: there is not an X Austin, a texting Austin, and an essay Austin. There is one thought process translated through different rooms. This repo exists to preserve that movement with evidence, not to split it into fake platform identities.

The shortest rule is newer and cleaner: **the best communication changes the doorway, not the truth.**

It is not a scrapbook, not a generic brand guide, and not a raw data landfill. It is a working voice skill backed by real source material across long-form writing, public social posts, professional documents, and privacy-safe derived analysis.

The goal is durable reuse:

- give future agents a canonical Austin voice reference;
- keep public writing, private-style drafts, social posts, and AI collaboration from drifting into generic chatbot prose;
- preserve the source archive without forcing every reader to dig through raw coursework, tweet exports, resume files, and generated artifacts;
- make the difference between verified evidence, reasoned synthesis, and open gaps explicit.

## Start Here

| Need | Open |
|---|---|
| Open the phone-friendly live preview | [GitHub Pages dossier](https://ahump20.github.io/Austin-Writing---Communication-Style-Archive/) |
| View the canonical dossier | [Austin Communication Translation System](Voice-Style-Identity/austin-communication-context-map.html) |
| Download the canonical pack | [Austin Communication Style Canonical Pack](dist/Austin-Communication-Style-Canonical-Pack-2026-07-07.zip) |
| Load the reusable voice skill | [Voice-Style-Identity/SKILL.md](Voice-Style-Identity/SKILL.md) |
| Read the canonical router | [Cross-Context Communication System](Voice-Style-Identity/cross-context-communication-system.md) |
| Read the visual delivery layer | [Visual Delivery Layer](Voice-Style-Identity/visual-delivery-layer.md) |
| Check source coverage and gaps | [Cross-Context Source Manifest](Voice-Style-Identity/cross-context-source-manifest.md) |
| Use the top-level instruction file | [Austin Voice Consolidated Harness](Voice-Style-Identity/austin-voice-consolidated-harness.md) |
| Review the full archive inventory | [docs/archive-inventory.md](docs/archive-inventory.md) |
| Understand repo architecture | [docs/repo-architecture.md](docs/repo-architecture.md) |

## What This System Does

- Routes the voice by room: public long-form, brand/platform, X/social, AI partner, friend group, warm private, coordination, and repair.
- Preserves one canonical Austin reference instead of splitting him into fake platform identities.
- Changes the doorway without changing the truth: same observation, audience-native entrance.
- Runs a cold-read guardrail against flattering, vague, or mystical claims. If a claim cannot be sourced, it stays reasoned/open or gets cut.
- Treats metaphor as audience translation: the same truth should move across cultures, contexts, and domains without making the room decode a foreign reference.
- Routes analogy by audience literacy, not Austin's default reference set. Sports, food, work, family ritual, place, tools, markets, faith, and school can all carry the same structure when the room shares the bridge.
- Keeps claims tied to source evidence and source-status tags.
- Gives future agents a reusable load order instead of a vague "write like me" request.

## Source Coverage

| Source lane | Status | What it contributes |
|---|---:|---|
| Long-form writing archive | [verified] | Academic, professional, strategic, sports, and business prose from 2014-2026. Best source for argument shape and public long-form voice. |
| Official X/Twitter exports | [verified] | 6,300 official rows, 5,437 authored voice rows, public humor, replies, sports/fan identity, and public-pressure translation across `@a_hump20` and `@TXTrickWhooper`. |
| Snapchat metadata export | [verified] | Privacy-safe derived private-register signals: short coordination, direct asks, quick reactions, warm one-on-one compression. Raw private text is not committed. |
| Living-brain bridge | [verified] | Durable routing note for agents and Obsidian context. Resurfaces Austin-derived language without filing generated prose as source truth. |
| iMessage / Apple Messages | [verified/private derived] | Privacy-safe aggregate metadata and private-language signals from the local Messages database: 483,242 total rows, 435,735 base human-message rows, 179,882 decoded sent text rows, 632 active group chats, reactions/tapbacks, reply threads, attachment shape, private wording rates, anonymous relationship-room shape, and purpose buckets. Raw private text, names, handles, and group names are not committed. |

## How To Use This Repo

For an agent or assistant:

1. Read [Voice-Style-Identity/SKILL.md](Voice-Style-Identity/SKILL.md).
2. Read [Voice-Style-Identity/cross-context-communication-system.md](Voice-Style-Identity/cross-context-communication-system.md).
3. Check [Voice-Style-Identity/cross-context-source-manifest.md](Voice-Style-Identity/cross-context-source-manifest.md) before making claims about source coverage.
4. Choose the room before writing: public long-form, public platform, X/social, friend group, warm private, coordination, repair, or AI-partner mode.
5. Choose the bridge before the analogy: what nearby domain does this audience already understand well enough to feel the point?
6. Treat generated Austin-style prose as output, not evidence.

For a person reviewing the archive:

1. Open the HTML dossier first.
2. Use the architecture doc to understand what each folder is for.
3. Use the archive inventory when you need the full file map.
4. Use source files only when you need evidence behind a voice claim.

## Router Modes

| Mode | Shape | Main evidence |
|---|---|---|
| Speaking with Austin | Outcome first. Known, unknown, open when stakes justify it. Warm, direct, no sycophancy. | Codex instructions, living-brain notes, current chat instructions |
| Public long-form | Claim early. Explain the system. Evidence at point of need. Close with the next move. | Coursework, research, sports writing, business plans |
| Public brand/platform | Vision over grievance. Concrete proof. Current doctrine over stale source docs. | Professional docs, origin story, brand files |
| X/social | Concrete noun, blunt verdict, absurd escalation, stop. | Official X archive |
| Friend-group / casual | Shorter, faster, more shorthand. Teasing through specifics. | Snapchat derived signals, iMessage derived language/context, X replies |
| Warm one-on-one | Specific attention, playful challenge, low pressure, brief. | Snapchat derived signals |
| Basic coordination | Direct ask, one useful detail, no ceremony. | Snapchat derived signals, iMessage private-language rates |
| Repair/vulnerable | Own the specific action, explain mechanism without excuse, state the next behavior. | Voice system plus direct user instructions |

## Current Brand Guardrails

[verified] Current BSI doctrine overrides stale archive language:

- Public brand name: **Blaze Sports Intel**.
- Austin title where useful: **Owner/Founder**.
- Public BSI product scope: **NCAA Division I college baseball only**.
- Tagline: **Sports Intelligence Put Simply**.
- Retired/stale public framing: `Blaze Intelligence` as parent brand, multi-sport platform claims, five-league positioning, and calling Austin an engineer.

Old documents may still contain historical language because this repo is an archive. The router docs and this README decide what is current.

## Repository Map

```text
Voice-Style-Identity/
  Canonical voice system, router, source manifest, generated dossier, visual-delivery layer, privacy-safe Snapchat analysis, and privacy-safe iMessage metadata/language analysis.

X-Twitter-Archive/
  Official X export parser outputs, X-only evidence artifact, tweet summaries, and public/social voice analysis.

Writing-Record/
  Long-form writing record, intellectual autobiography, and consolidated prose analysis.

UT-Austin-Coursework/
  Undergraduate archive. Best source for pre-AI analytical writing and argument development.

Full-Sail-Coursework/
  Graduate sports-business archive. Useful for AI-supplemented professional and strategic prose.

Sports-Writing/
  Applied public sports voice, especially baseball analysis and editorial rhythm.

Research/
  AI economics, NIL, and related research artifacts.

Austin_Humphrey_Resume_Package/
  Professional materials. Use carefully because some older BSI positioning can be historically useful but not current.

scripts/
  Parsers, artifact builders, guardrails, and validation scripts.

docs/
  Repo architecture and full archive inventory.
```

## Generated Artifacts

| Artifact | Purpose |
|---|---|
| [Voice-Style-Identity/austin-communication-context-map.html](Voice-Style-Identity/austin-communication-context-map.html) | Canonical React translation system for usable voice outputs, doorway plays, system behavior, anonymous private-room shape, purpose buckets, evidence strength, and privacy boundaries. |
| [dist/Austin-Communication-Style-Canonical-Pack-2026-07-07.zip](dist/Austin-Communication-Style-Canonical-Pack-2026-07-07.zip) | One portable, privacy-safe reference pack for the current communication system. |
| [Voice-Style-Identity/visual-delivery-assets/doorway-translation-flow.svg](Voice-Style-Identity/visual-delivery-assets/doorway-translation-flow.svg) | Annotated doorway flow: truth core, room read, doorway, tone, proof, action. |
| [Voice-Style-Identity/visual-delivery-assets/error-recovery-flow.svg](Voice-Style-Identity/visual-delivery-assets/error-recovery-flow.svg) | Annotated error-recovery flow derived from the added visual context without storing the raw screenshot. |
| [Voice-Style-Identity/visual-delivery-assets/semantic-portability-map.svg](Voice-Style-Identity/visual-delivery-assets/semantic-portability-map.svg) | Annotated truth-transfer flow: observation, mechanism, audience world, bridge, contextual acuteness, delivery, and durability. |
| [Voice-Style-Identity/imessage-analysis/2026-07-07/imessage_private_context_summary.md](Voice-Style-Identity/imessage-analysis/2026-07-07/imessage_private_context_summary.md) | Privacy-safe iMessage metadata summary for private group/direct shape, tapbacks, replies, and attachments. |
| [Voice-Style-Identity/imessage-analysis/2026-07-07/imessage_private_language_summary.md](Voice-Style-Identity/imessage-analysis/2026-07-07/imessage_private_language_summary.md) | Privacy-safe iMessage private-language summary for decoded sent-text length, marker rates, anonymous relationship-context router, and purpose buckets. |

## Privacy Rules

- Do not commit raw Snapchat private text, contact names, media URLs, location data, phone/email identifiers, or media files.
- Do not commit raw iMessage private text, contact names, handles, group names, filenames, attachment contents, media paths, private relationship maps, burner/account metadata, or DM exports. Commit only privacy-safe aggregate summaries; keep raw/private audits in ignored local-only paths.
- Do not treat reposts, likes, follows, viewed content, or generated Austin-style prose as Austin-authored voice.
- Keep private-source material as summaries, marker counts, source manifests, and router corrections unless the user asks otherwise.

## Maintenance

When adding new source material:

1. Put raw public exports in the relevant archive lane.
2. Keep private data out of git unless it has been transformed into a privacy-safe derived summary.
3. Update the source manifest with coverage, exclusions, and open gaps.
4. Rebuild the artifact if the canonical communication model changes.
5. Update local skills only with durable synthesis, not one-off generated prose.

When cleaning the repo:

- Remove generated artifacts only when a newer canonical artifact fully replaces their purpose.
- Preserve historical documents even when their claims are stale, but mark stale public guidance clearly.
- Keep proof files when they explain parser behavior, source boundaries, or validation state.

## License

All rights reserved. The archive contains personal writing, educational material, private-derived summaries, and identity/voice references. Do not reuse, train on, publish, or redistribute without Austin Humphrey's explicit permission.
